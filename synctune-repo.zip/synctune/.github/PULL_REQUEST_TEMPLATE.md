## Summary

<!-- What does this PR do, and why? One or two sentences. -->

Closes #

## Type of change

- [ ] `feat` — new functionality
- [ ] `fix` — bug fix
- [ ] `docs` — documentation only
- [ ] `refactor` — no behavior change
- [ ] `test` — tests only
- [ ] `ci` / `chore` — tooling, workflow, or maintenance

## How was this tested?

<!-- Manual steps, test cases added, providers/accounts used. For transfer
     logic: playlist size, source → destination, and edge cases exercised. -->

## Checklist

- [ ] `npm run lint` passes
- [ ] `npm test` passes (new logic in `src/lib/matching/` has coverage)
- [ ] `npm run build` passes
- [ ] Commits follow [Conventional Commits](../CONTRIBUTING.md#commit-messages--conventional-commits)
- [ ] No secrets, tokens, or `.env` values committed
- [ ] Docs / ROADMAP updated if behavior or architecture changed
